import React from "react";
import IndexNavbar from "components/Navbars/IndexNavbar.js";



export default function Register() {
  return (
    <>
    
     <h1>helloooooo </h1>
    </>
  );
}

